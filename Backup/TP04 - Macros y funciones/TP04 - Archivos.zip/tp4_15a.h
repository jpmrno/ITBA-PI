/* Biblioteca  para obtener el mayor de 3 numeros */

int fAuxiliar (int m, int n);

int mayor3 (int n, int m, int p);

