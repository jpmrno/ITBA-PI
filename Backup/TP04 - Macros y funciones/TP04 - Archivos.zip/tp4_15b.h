/* Biblioteca para obtener el promedio de 3 enteros */

int fAuxiliar (int n, int m, int p);

float promedio3 (int n, int m, int p);
