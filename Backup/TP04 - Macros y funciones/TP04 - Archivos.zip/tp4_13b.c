float
f2(float x)
{
	return 3 * x;
}
