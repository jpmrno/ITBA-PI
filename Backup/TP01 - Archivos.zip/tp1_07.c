#include <stdio.h>

int j;
float x;
char letra;
