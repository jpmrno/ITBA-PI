#include "tp1_12.h"

int
main(void)
{
	int i = FALSE;
	int j = TRUE;
	return 0;
}
