#include <stdio.h>

#define NRO 019 

int
main(void)
{
	long i = NRO ;
	printf("%ld\n",i);
	return 0;
}
