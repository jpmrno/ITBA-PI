#include <stdio.h>

#define NRO 50000009999999l

int
main(void)
{
	long i = 900;
	printf("%ld\n",i);
	return 0;
}
