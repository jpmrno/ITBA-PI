#include <stdio.h>

int
main(void)
{
	int i;
	printf ("%d\n",i);
	return 1;
}

int
main(void)
{
	char a='Z';
	printf("Hola %d",a);
	return 0;
}
