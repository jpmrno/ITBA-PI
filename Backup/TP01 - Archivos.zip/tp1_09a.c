int
main(void)
{
	int a=0;

	a++;
	return 0;
}
