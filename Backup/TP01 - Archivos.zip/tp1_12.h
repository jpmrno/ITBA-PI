#define TRUE 1
#define FALSE ! TRUE

float nada(void);
