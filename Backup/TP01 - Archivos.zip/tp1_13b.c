#include <stdio.h>

#define NRO 50000009999999l

int
main(void)
{
	long i = NRO ;
	printf("%ld\n",i);
	return 0;
}
